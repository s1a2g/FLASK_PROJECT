import csv

def average(filename):
    tot = 0.0  
    stu = 0

    with open(filename, 'r') as csvfile:
        rea = csv.reader(csvfile)
        hea = next(rea) 

        for row in rea:
            name, age, grade = row
            tot += float(grade)  
            stu+= 1

    avg = tot / stu if stu > 0 else 0  
    return avg

def highestgradestudent(filename):
    highestgrade = float('-inf')  
    hgs = None

    with open(filename, 'r') as csvfile:
        rea = csv.reader(csvfile)
        hea = next(rea)  

        for row in rea:
            name, age, grade = row
            gvalue = float(grade) 
            if gvalue > highestgrade:
                highestgrade = gvalue
                hgs = name

    return hgs
filename = "studentdetails.csv"
avg = average(filename)
print(avg)

hgs = highestgradestudent(filename)
print( hgs)
