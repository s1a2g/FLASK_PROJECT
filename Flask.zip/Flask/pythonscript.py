import csv

def calculate_average_grade(filename):
    total_grade = 0.0  
    num_students = 0

    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader) 

        for row in reader:
            name, age, grade = row
            total_grade += float(grade)  
            num_students += 1

    average_grade = total_grade / num_students if num_students > 0 else 0  # Avoid division by zero
    return average_grade

def find_highest_grade_student(filename):
    highest_grade = float('-inf')  
    highest_grade_student = None

    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader)  

        for row in reader:
            name, age, grade = row
            grade_value = float(grade) 
            if grade_value > highest_grade:
                highest_grade = grade_value
                highest_grade_student = name

    return highest_grade_student
filename = "students.csv"
average_grade = calculate_average_grade(filename)
print("Average grade:", average_grade)

highest_grade_student = find_highest_grade_student(filename)
print("Student with the highest grade:", highest_grade_student)
